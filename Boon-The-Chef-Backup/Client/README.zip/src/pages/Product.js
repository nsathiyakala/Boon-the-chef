import React, { Fragment, useEffect, useState } from 'react';
import Navbar from '../components/navbar';
import Footer from '../components/footerpage';
import WholeProduct from '../components/wholeProduct';
import Search from '../components/search';
import { useSearchParams } from 'react-router-dom';
// import ProductCard from '../components/productCard';

export default function Products() {
  const [products, setProducts] = useState([]);
  const [searchParams,setSearchParams] =useSearchParams();
  
  useEffect(() => {
    fetch('http://localhost:8000/boonthechef/products'+searchParams)
      .then(res => res.json())
      .then(res => setProducts(res.products))
      .catch(error => console.error('Error fetching products:', error));
  }, [searchParams]);

  
  return (
    <Fragment>
      <Navbar />
      <div className='all-products-sec'>
        <h2 className='text-center'>Home/Products</h2>
        <h1 className='text-center'> Products</h1>
        <div className='container all-products-container mt-5'>
          <div className='row'>
            <div className='col-12 col-md-3 order-3 order-md-0 product-filter'>
            <h3 className='pt-3 pb-3'>Filter</h3>
             <form className="d-flex mb-3" role="search">
              <Search/>
            </form>
                    <div className='offer-products mt-5'>
                      <div className='Product-img'>
                      <img className='img-fluid' src="./images/thinai.webp" alt="thinai-img" />
                      </div>
                      <h4>Thinai Dosai Mix(FoxTail Millet)</h4>
                      <p>₹165</p>
                    </div>
                    <div className='offer-products'>
                      <div className='Product-img'>
                      <img className='img-fluid' src="./images/thinai.webp" alt="thinai-img" />
                      </div>
                      <h4>Thinai Dosai Mix(FoxTail Millet)</h4>
                      <p>₹165</p>
                    </div>
                    <div className='offer-products'>
                      <div className='Product-img'>
                      <img className='img-fluid' src="./images/thinai.webp" alt="thinai-img" />
                      </div>
                      <h4>Thinai Dosai Mix(FoxTail Millet)</h4>
                      <p>₹165</p>
                    </div>
            </div>
            <div className='col'>
              <div className='vertical-line'></div>
            </div>
            <div className='col-12 col-md-8 order-0 order-md-3 all-products'>
              <div className='container'>
                <div className='row'>
                {products && products.map(product => (
                  <WholeProduct key={product._id} product={product} />
                ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </Fragment>
  );
}
