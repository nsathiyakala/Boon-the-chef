import { Fragment, useEffect, useState } from "react";
import { useParams } from "react-router-dom";

export default function WholeProductDetails(){
  const [product,setProduct]=useState(null);
  const {id} =useParams();
  useEffect(() => {
    fetch(`http://localhost:8000/boonthechef/products ${id}`)
      .then(res => res.json())
      .then(res => setProduct(res.wholeProduct))
      .catch(error => console.error('Error fetching product:', error));
  }, [id]);
  return(
    <Fragment>

    </Fragment>
  )
}