import React from 'react';

export default function Testimonial() {
    return (
        <div className="container mt-4">
            <div className="row mt-4 p-5">
                <div className="col-lg-4">
                    <div className="card">
                    <div className="card-body text-center">
                                <div className="card-tittle">
                                    <i className="fa fa-star"></i>
                                    <i className="fa fa-star"></i>
                                    <i className="fa fa-star"></i>
                                    <i className="fa fa-star"></i>
                                    <i className="fa fa-star"></i>
                                </div>
                                <div className="card-text mt-3">
                                    <p>
                                        Millets offer a nutritious alternative to grains, rich in fiber and essential nutrients. Their versatility makes them a valuable addition to any diet, promoting stable blood sugar levels and overall health.
                                    </p>
                                </div>
                                <div className="card-pic d-flex justify-content-center align-items-center mt-3">
                                    <img src="./images/profile.png" className="img-fluid" style={{ maxWidth: "100px" }} />
                                    <h3 className="text-center mt-2">John</h3>
                                </div>
                            </div>                    </div>
                </div>
                <div className="col-lg-4 d-flex justify-content-center">
                    <div className="card">
                    <div className="card-body text-center">
                            <div className="card-tittle">
                                <i className="fa fa-star"></i>
                                <i className="fa fa-star"></i>
                                <i className="fa fa-star"></i>
                                <i className="fa fa-star"></i>
                                <i className="fa fa-star"></i>
                            </div>
                            <div className="card-text mt-3">
                                <p>
                                    Millets offer a nutritious alternative to grains, rich in fiber and essential nutrients. Their versatility makes them a valuable addition to any diet, promoting stable blood sugar levels and overall health.
                                </p>
                            </div>
                            <div className="card-pic d-flex justify-content-center align-items-center mt-3">
                                <img src="./images/profile.png" className="img-fluid" style={{ maxWidth: "100px" }} />
                                <h3 className="text-center mt-2">John</h3>
                            </div>
                        </div>                    </div>
                </div>
                <div className="col-lg-4">
                    <div className="card">

                         
                    <div className="card-body text-center">
                        <div className="card-tittle">
                            <i className="fa fa-star"></i>
                            <i className="fa fa-star"></i>
                            <i className="fa fa-star"></i>
                            <i className="fa fa-star"></i>
                            <i className="fa fa-star"></i>
                        </div>
                        <div className="card-text mt-3">
                            <p>
                            Kampu Solam's earthy flavor and dense texture offer a nutritious alternative to traditional grains, rich in fiber and essential nutrients, perfect for enhancing diverse cuisines and promoting overall health.
                        </p>
                        </div>
                        <div className="card-pic d-flex justify-content-center align-items-center mt-3">
                            <img src="./images/profile.png" className="img-fluid" style={{ maxWidth: "100px" }} />
                            <h3 className="text-center mt-2">John</h3>
                        </div>
                    </div>                    </div>
                </div>
            </div>
        </div>
    );
}


