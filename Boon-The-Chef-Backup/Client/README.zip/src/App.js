import './App.css';
import Home from './pages/Home';
import {Routes,Route,BrowserRouter,Link, Router} from 'react-router-dom'
import ProductDetails from './pages/productDetails';
import Products from './pages/Product';
import About from './pages/About';
import Contact from './pages/contact';
import WholeProductDetails from './pages/wholeProductdetails';
import WholeProduct from './components/wholeProduct';
import { useState } from 'react';
import 'react-toastify/dist/ReactToastify.css';
import {ToastContainer} from 'react-toastify'
import Cart from './pages/cart';
 

function App() {
  const[cartItems,setCartItems]=useState([]);

  return (
    <BrowserRouter>
        <ToastContainer theme='dark' position='top-center'/>
        <Routes>
   <Route path='/' element={<Home/>}/>
  <Route path='/Home' element={<Home cartItems={cartItems}/>}/>
  <Route path='/search' element={<WholeProduct/>}/>
  <Route path='/product/:id' element={<ProductDetails cartItems={cartItems} setCartItems={setCartItems}/>}/>
  <Route path='/products' element= {<Products/>}/>
  <Route path='/about' element={<About />}/>
  <Route path='/contact' element={<Contact />}/>
  <Route path='/products/:id' element={<WholeProductDetails/>}/>
  <Route path='/cart' element={<Cart cartItems={cartItems} setCartItems={setCartItems}/>}/>


   </Routes>
   </BrowserRouter>
      );
}

export default App;
