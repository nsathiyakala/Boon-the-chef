import { useState } from "react";
import { useNavigate } from "react-router-dom";

export default function Search() {
  const navigate = useNavigate();
  const [keyword, setKeyword] = useState('');

  const submitHandler = () => {
    navigate('/search?keyword=' + keyword);
  };

  return (
    <>
      <input 
        className="form-control me-2" 
        onChange={(e) => setKeyword(e.target.value)} 
        type="search" 
        placeholder="Search" 
        aria-label="Search" 
      />
      <button 
        className="btn btn-outline-success" 
        type="submit" 
        onClick={submitHandler}
      >
        Search
      </button>
    </>
  );
}
