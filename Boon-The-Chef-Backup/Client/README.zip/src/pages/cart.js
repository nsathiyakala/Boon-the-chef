import React, { Fragment } from "react";
import Footer from "../components/footerpage";
import Navbar from "../components/navbar";
import { Link } from "react-router-dom";

export default function Cart({ cartItems, setCartItems }) {
  const handleQuantityChange = (productId, quantity) => {
    const updatedCartItems = cartItems.map(item =>
      item.product._id === productId ? { ...item, quantity: parseInt(quantity) } : item
    );
    setCartItems(updatedCartItems);
  };

  const removeItem = (productId) => {
    const updatedCartItems = cartItems.filter(item =>
      item.product._id !== productId
    );
    setCartItems(updatedCartItems);
  };

  const subtotal = cartItems.reduce((acc, item) => acc + item.quantity, 0);
  const total = cartItems.reduce((acc, item) => acc + item.product.price * item.quantity, 0);
  console.log(total);

  return (
    <Fragment>
      <Navbar cartItems={cartItems} />
      <h2 className="text-center">Your cart: {subtotal} Items</h2>
      <div className="row d-flex justify-content-between">
        <div className="col-12 col-lg-8">
          {cartItems.map((item) => (
            <Fragment key={item.product._id}>
              <hr />
              <div className="cart-item">
                <div className="row">
                  <div className="col-4 col-lg-3">
                    <img src={item.product.images[0].image} alt="Laptop" height="90" width="115" />
                  </div>
                  <div className="col-5 col-lg-3">
                    <Link to={'/product/' + item.product._id}><h3>{item.product.name}</h3></Link>
                    <a href="#" className="cart-item-link">{item.product.description}</a>
                  </div>
                  <div className="col-4 col-lg-2 mt-4 mt-lg-0">
                    <p id="card_item_price">${item.product.price}</p>
                  </div>
                  <div className="col-4 col-lg-3 mt-4 mt-lg-0">
                    <div className="stockCounter d-inline">
                      <button
                        className="btn btn-black minus"
                        onClick={() => handleQuantityChange(item.product._id, item.quantity - 1)}
                        disabled={item.quantity <= 1}
                      >-</button>
                      <input
                        type="number"
                        className="form-control count d-inline"
                        value={item.quantity}
                        onChange={(e) => handleQuantityChange(item.product._id, e.target.value)}
                        min={1}
                      />
                      <button
                        className="btn btn-black plus"
                        onClick={() => handleQuantityChange(item.product._id, item.quantity + 1)}
                      >+</button>
                    </div>
                  </div>
                  <div className="col-4 col-lg-1 mt-4 mt-lg-0">
                    <i id="delete_cart_item" onClick={() => removeItem(item.product._id)} className="fa fa-trash btn btn-black"></i>
                  </div>
                </div>
              </div>
            </Fragment>
          ))}
        </div>
        <div className="col-12 col-lg-3 my-4">
          <div id="order_summary">
            <h4>Order Summary</h4>
            <hr />
            <p>Subtotal: <span className="order-summary-values">{subtotal} (Units)</span></p>
            <p>Est. total: <span className="order-summary-values">${total.toFixed(2)}</span></p>
            <hr />
            <button id="checkout_btn" className="btn btn-black btn-block">Place Order</button>
          </div>
        </div>
      </div>
      <Footer />
    </Fragment>
  );
}
