import React, { Fragment, useEffect, useState } from 'react';
import ProductCard from '../components/productCard';
import ShopNow from '../components/shopnow';
// import Navbar from '../components/navbar';
import Footer from '../components/footerpage';
import HomeBanner from '../components/banner';
import ShopnowBox from '../components/shopnowbox';
import Testimonal from '../components/testimonal';
import { useSearchParams } from 'react-router-dom';
import { Link } from 'react-router-dom';

function Home({cartItems}) {
  const [products, setProducts] = useState([]);
  const [searchParams] = useSearchParams();

  useEffect(() => {
    fetch(`http://localhost:8000/boonthechef/products?${searchParams.toString()}`)
      .then(res => {
        if (!res.ok) {
          throw new Error('Network response was not ok');
        }
        return res.json();
      })
      .then(data => setProducts(data.products))
      .catch(error => console.error('Fetch error:', error));
  }, [searchParams]);

  return (
    <Fragment>
 <nav className="navbar navbar-expand-lg">
        <div className="container-fluid d-flex justify-content-between align-items-center">
          <div className="logo-img">
            <img className="img-fluid logo" src="./images/logo.png" alt="" style={{ width: '90px' }} />
          </div>
          <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarSupportedContent">
            <ul className="navbar-nav me-auto mb-2 mb-lg-0" >
              <li className="nav-item">
                <Link to='/Home' className="nav-link">Home</Link>
              </li>
              <li className="nav-item">
                <Link to='/products' className="nav-link">Products</Link>
              </li>
              <li className="nav-item">
                <Link to='/about' className="nav-link">About</Link>
              </li>
              <li className="nav-item">
                <Link to='/contact' className="nav-link">Contact</Link>
              </li>
            </ul>
            {/* <form className="d-flex" role="search">
              <Search />
            </form> */}
            <div className="d-flex align-items-center icons">
              <Link to={'/cart'} className="me-3 text-dark text-decoration-none">
                <i className="fas fa-shopping-cart"></i> 
                <span id='cart-count' className='text-dark'>{ cartItems && cartItems.length}</span>
                    {/* Add to Cart symbol */}
              </Link>
              <Link to='/user' className="text-dark text-decoration-none">
                <i className="fas fa-user"></i> {/* User icon */}
              </Link>
            </div>
          </div>
        </div>
      </nav>      <HomeBanner />
      {/* card start */}
      <section id="products" className="container mt-5">
        <div className="row">
          <h1 className='text text-center mt-5'>Best Selling Products</h1>
          {products && products.slice(0, 4).map(product => <ProductCard key={product._id} product={product} />)}
        </div>
      </section>
      <section className='container-fluid shop-now p-4'>
        <ShopNow />
      </section>
      <section className='container-fluid bg-dark'>
        <ShopnowBox />
      </section>
      <div className='container-fluid mt-4 mb-4'>
        <b>
          <h3 className='bg-white text-dark text-center'>Purchase all your MILLETS under one roof</h3>
        </b>
      </div>
      <section className='container-fluid testimonal'>
        <h3 className='tesimonals-text text-center'>Testimonial</h3>
        <Testimonal />
      </section>
      <Footer />
    </Fragment>
  );
}

export default Home;
